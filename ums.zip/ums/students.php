<?php
session_start();
include("includes/db_connect.php");
$result = mysqli_query($conn, "SELECT * FROM students");
?>

<!DOCTYPE html>
<html>
<head>
<title>Students</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
<h2 class="title">Students</h2>

<a href="add_student.php" class="btn">Add Student</a>

<table>
<tr><th>ID</th><th>Name</th><th>Email</th></tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['email'] ?></td>
</tr>
<?php } ?>

</table>
<script src="assets/js/main.js"></script>
</body>
</html>
