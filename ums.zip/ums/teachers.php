<?php
include("includes/db_connect.php");
$result = mysqli_query($conn, "SELECT * FROM teachers");
?>

<h2 class="title">Teachers</h2>
<a href="add_teacher.php" class="btn">Add Teacher</a>

<table>
<tr><th>ID</th><th>Name</th></tr>
<?php while($row=mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['name'] ?></td>
</tr>
<?php } ?>
</table>
<script src="assets/js/main.js"></script>