<?php
include("includes/db_connect.php");
$result = mysqli_query($conn, "SELECT * FROM courses");
?>

<h2 class="title">Courses</h2>
<a href="add_course.php" class="btn">Add Course</a>

<table>
<tr><th>ID</th><th>Name</th></tr>
<?php while($row=mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['name'] ?></td>
</tr>
<?php } ?>
</table>
<script src="assets/js/main.js"></script>