<div class="container">
<h2>Add Teacher</h2>

<form action="api/add_teacher.php" method="POST">
<input type="text" name="name" required>
<button>Add</button>
</form>
</div>
<script src="assets/js/main.js"></script>