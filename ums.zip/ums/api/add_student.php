<?php
include("../includes/db_connect.php");

$name  = mysqli_real_escape_string($conn, $_POST['name']);
$email = mysqli_real_escape_string($conn, $_POST['email']);

mysqli_query($conn, "INSERT INTO students (name,email) VALUES ('$name','$email')");
header("Location: ../students.php");
?>
