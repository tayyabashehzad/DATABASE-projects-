<?php
include("../includes/db_connect.php");
$name = mysqli_real_escape_string($conn, $_POST['name']);
mysqli_query($conn, "INSERT INTO courses (name) VALUES ('$name')");
header("Location: ../courses.php");
?>
