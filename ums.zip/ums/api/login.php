<?php
session_start();
include("../includes/db_connect.php");

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $_SESSION['admin'] = $username;
    header("Location: ../dashboard.php");
} else {
    echo "Invalid Login";
}
?>
