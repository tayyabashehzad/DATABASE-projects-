<?php
$host = "sql300.infinityfree.com";     // change on InfinityFree
$user = "if0_40917097";          // change on InfinityFree
$pass = "eqyrWDGU97Z";              // change on InfinityFree
$db   = "if0_40917097_ums";           // change on InfinityFree

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database Connection Failed");
}
?>
