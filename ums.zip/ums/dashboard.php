<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<h2 class="title">Dashboard</h2>

<div class="grid">
    <a class="card" data-aos="zoom-in" href="students.php">
        <i class="fa-solid fa-user-graduate"></i>
        <p>Students</p>
    </a>

    <a class="card" data-aos="zoom-in" href="teachers.php">
        <i class="fa-solid fa-chalkboard-user"></i>
        <p>Teachers</p>
    </a>

    <a class="card" data-aos="zoom-in" href="courses.php">
        <i class="fa-solid fa-book"></i>
        <p>Courses</p>
    </a>

    <a class="card logout" data-aos="zoom-in" href="logout.php">
        <i class="fa-solid fa-right-from-bracket"></i>
        <p>Logout</p>
    </a>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>AOS.init();</script>
<script src="assets/js/main.js"></script>
</body>
</html>
