<!DOCTYPE html>
<html>
<head>
<title>Add Student</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
<h2>Add Student</h2>

<form action="api/add_student.php" method="POST">
<input type="text" name="name" placeholder="Name" required>
<input type="email" name="email" placeholder="Email" required>
<button>Add</button>
</form>
</div>
<script src="assets/js/main.js"></script>
</body>
</html>
