<div class="container">
<h2>Add Course</h2>

<form action="api/add_course.php" method="POST">
<input type="text" name="name" required>
<button>Add</button>
</form>
</div>
<script src="assets/js/main.js"></script>