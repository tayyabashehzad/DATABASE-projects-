// ===============================
// UMS Main JavaScript File
// ===============================

// Page load animation
document.addEventListener("DOMContentLoaded", () => {
    document.body.style.opacity = "0";
    document.body.style.transition = "opacity 0.8s ease-in-out";

    setTimeout(() => {
        document.body.style.opacity = "1";
    }, 100);
});

// Button hover sound effect (optional)
document.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("mouseenter", () => {
        btn.style.transform = "translateY(-2px)";
    });

    btn.addEventListener("mouseleave", () => {
        btn.style.transform = "translateY(0)";
    });
});

// 3D card tilt effect
document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("mousemove", e => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = (y - centerY) / 15;
        const rotateY = (centerX - x) / 15;

        card.style.transform = `
            perspective(1000px)
            rotateX(${rotateX}deg)
            rotateY(${rotateY}deg)
            scale(1.05)
        `;
    });

    card.addEventListener("mouseleave", () => {
        card.style.transform = "translateY(-10px) scale(1)";
    });
});

// Simple confirmation for logout
document.querySelectorAll(".logout").forEach(btn => {
    btn.addEventListener("click", e => {
        if (!confirm("Are you sure you want to logout?")) {
            e.preventDefault();
        }
    });
});
